import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;

public class Controller {
    private Elevator elevator;
    HashSet<Person> on = new HashSet<Person>();
    HashSet<Person> off = new HashSet<Person>();

    public Controller(Elevator elevator) {
        this.elevator = elevator;
        //use algorithm to decide the next target
        this.targetFloor();
    }

    public HashSet<Person> getOn() {
        return on;
    }

    public HashSet<Person> getOff() {
        return off;
    }


    public void targetFloor() {
        HashMap<Integer, HashSet<Person>> waiting = elevator.getWaiting();
        Integer curr = elevator.getCurrFloor();
        int max = 0;
        int maxkey = 0;
        int dir = 0;
        for (int key : waiting.keySet()) {
            if (Math.abs(key - curr) > max) {
                max = Math.abs(key - curr);
                maxkey = key;
                dir = (key - curr) < 0 ? Constant.DOWN : Constant.UP;
            }
        }
        elevator.changeCurr(dir);
        elevator.setTargetFloor(maxkey);
    }

    //whether it's needed to stop the elevator
    public boolean stop() {
        HashMap<Integer, HashSet<Person>> passengers = elevator.getPassengers();
        HashMap<Integer, HashSet<Person>> waiting = elevator.getWaiting();
        Integer curr = elevator.getCurrFloor();
        Integer capacity = elevator.getCapacity();
        HashSet<Person> temp;
        boolean hasOff = elevator.getPassengers().containsKey(curr);
        boolean hasOn = false;
        if (hasOff) {
            off.clear();
            off.addAll(passengers.get(curr));
            passengers.get(curr).forEach((p) -> {
                p.setFinished(true);
            });
            passengers.remove(curr);
            elevator.changeCurr(-off.size());
        }
        if (!elevator.isFull() && waiting.containsKey(curr)) {
            on.clear();
            temp = waiting.get(curr);
            on.addAll(grab(temp));//grab fastest people in
        }
        return hasOn && hasOff;
    }

    public HashSet<Person> grab(HashSet<Person> waitlist) {
        HashSet<Person> temp = new HashSet<Person>();
        ArrayList<Person> sameDir = new ArrayList<Person>();

        for (Person person : waitlist) {
            if (elevator.getState() == Constant.UP && person.goUp()) {
                sameDir.add(person);
            } else if (elevator.getState() == Constant.DOWN && !person.goUp()) {
                sameDir.add(person);
            }
        }

        //sort the same direction people by distance
        Collections.sort(sameDir, new Comparator<Person>() {
            @Override
            public int compare(Person o1, Person o2) {
                return o1.getDistance() > o2.getDistance() ? 1 : -1;
            }
        });

        int vacancy = elevator.getCapacity() - elevator.getCurNum();
        if (sameDir.size() <= vacancy) {
            temp.addAll(sameDir);
        } else {
            temp.addAll(sameDir.subList(0, vacancy));
        }


        return temp;
    }
}
