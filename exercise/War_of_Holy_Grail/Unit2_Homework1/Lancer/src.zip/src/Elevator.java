import com.oocourse.TimableOutput;

import java.util.HashMap;
import java.util.HashSet;

public class Elevator implements Runnable {
    private int state;
    private int currFloor;
    private int targetFloor;
    private char nameBuild;
    private int eleID;
    private int capacity;//6
    private int curNum;//current number of people in ele
    private long speed;//ms between floor 400
    private HashMap<Integer, HashSet<Person>> passengers;
    //passengers:key:destFloor value:people in the elevator
    private Controller controller;
    private Request request;

    public Elevator(int currFloor, int eleID, char nameBuild,int capacity, long speed, Request request) {
        this.currFloor = currFloor;
        this.eleID = eleID;
        this.capacity = capacity;
        this.speed = speed;
        this.request = request;
        this.nameBuild = nameBuild;
    }

    @Override
    public void run() {
        while (true) {
            if(request == null){
                try {
                    synchronized (this) {
                        this.wait();
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            else if(request.getWaitingList().isEmpty()){
                try {
                    if (passengers.isEmpty() && request.isFinished()) {
                        break;
                    }
                    synchronized (this){
                        this.wait();
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            controller = new Controller(this);
            move();
            while (currFloor != targetFloor) {
                if (controller.stop()) {
                    gap();
                }
                move();
            }
            gap();
        }
    }

    public void gap() {
        HashMap<Integer,HashSet<Person>> waiting = request.getWaitingList();
        //people waiting for this elevator
        open();
        state = Constant.WAIT;
        sleep(200);
        controller.getOff().forEach((p) -> {
            out(p);
            if(passengers.get(currFloor).size() == 1){
                passengers.remove(currFloor);
            }else{
                passengers.get(currFloor).remove(p);
            }
        });
        controller.getOn().forEach((p) -> {
            in(p);
            if(waiting.get(currFloor).size() == 1){
                waiting.remove(currFloor);
            }else{
                waiting.get(currFloor).remove(p);
            }
        });
        sleep(200);
        close();
    }

    public void changeDir(int dir){
        this.state = dir;
    }

    public Request getRequest() {
        return request;
    }

    public HashMap<Integer, HashSet<Person>> getWaiting() {
        return request.getWaitingList();
    }

    public int getCurNum() {
        return curNum;
    }

    public int getState() {
        return state;
    }

    public boolean isFull() {
        return curNum == capacity;
    }

    public void changeCurr(int delta) {
        curNum += delta;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setTargetFloor(int targetFloor) {
        this.targetFloor = targetFloor;
    }

    public HashMap<Integer, HashSet<Person>> getPassengers() {
        return passengers;
    }

    public int getCurrFloor() {
        return currFloor;
    }

    public void open() {
        //make sure output is in time order
        synchronized (TimableOutput.class) {
            TimableOutput.println(String.format("OPEN-" + nameBuild + "-" + currFloor + "-" + eleID));
        }
    }

    public void in(Person person) {
        synchronized (TimableOutput.class) {
            TimableOutput.println(String.format("IN-" + person.getId() + "-" + nameBuild + "-" + currFloor + "-" + eleID));
        }
    }

    public void out(Person person) {
        synchronized (TimableOutput.class) {
            TimableOutput.println(String.format("OUT-" + person.getId() + "-" + nameBuild + "-" + currFloor + "-" + eleID));
        }
    }

    public void close() {
        synchronized (TimableOutput.class) {
            TimableOutput.println(String.format("CLOSE-" + nameBuild + "-" + currFloor + "-" + eleID));
        }
    }

    public void arrive() {
        synchronized (TimableOutput.class) {
            TimableOutput.println(String.format("ARRIVE-" + nameBuild + "-" + currFloor + "-" + eleID));
        }
    }

    public void sleep(long time) {
        try {
            Thread.sleep(time);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void move() {
        sleep(speed);
        if (state == Constant.DOWN) {
            currFloor -= 1;
            arrive();
        } else if (state == Constant.UP) {
            currFloor += 1;
            arrive();
        }
    }

}
