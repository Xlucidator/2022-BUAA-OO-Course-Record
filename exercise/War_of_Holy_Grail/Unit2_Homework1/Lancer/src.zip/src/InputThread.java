import com.oocourse.elevator1.ElevatorInput;
import com.oocourse.elevator1.PersonRequest;

public class InputThread implements Runnable{
    private Request[] requestlist;

    public InputThread(Request[] requestlist) {
        this.requestlist = requestlist;
    }

    @Override
    public void run() {
        Person p;
        int dest;
        char fromBuild;
        ElevatorInput elevatorInput = new ElevatorInput(System.in);
        while(true){
            PersonRequest personrequest = elevatorInput.nextPersonRequest();
            if(personrequest == null){
                for(Request r:requestlist){
                    synchronized (r){
                        r.setFinished(true);
                    }
                }
                break;
            }else{
                dest = personrequest.getToFloor();
                fromBuild = personrequest.getFromBuilding();
                System.out.println(fromBuild);
                p = new Person(personrequest);
                requestlist[fromBuild-'A'].add(dest,p);
            }
        }
    }
}
