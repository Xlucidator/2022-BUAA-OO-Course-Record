public class Constant {
    public static final int DOWN = -1;
    public static final int WAIT = 0;
    public static final int UP = 1;

    public static final int A = 0;
    public static final int B = 1;
    public static final int C = 2;
    public static final int D = 3;
    public static final int E = 4;
}

