import java.util.HashMap;
import java.util.HashSet;

//shared object
public class Request {
    //(k,v)->v waiting in k floor
    private HashMap<Integer, HashSet<Person>> waitingList;
    private boolean finished;

    public Request() {
        this.waitingList = new HashMap<>();
    }

    public synchronized void add(Integer dest, Person p){
        if(waitingList.containsKey(dest)){
            waitingList.get(dest).add(p);
        }else{
            HashSet<Person> tmp = new HashSet<>();
            tmp.add(p);
            waitingList.put(dest,tmp);
        }
        notifyAll();
    }

    public synchronized void remove(Integer dest,Person p){
        if(waitingList.get(dest).size() == 1){
            waitingList.remove(dest);
        }else{
            waitingList.get(dest).remove(p);
        }
    }

    public synchronized void setFinished(boolean finished){
        this.finished = finished;
        notifyAll();
    }

    public boolean isFinished() {
        return finished;
    }

    public HashMap<Integer, HashSet<Person>> getWaitingList() {
        return waitingList;
    }
}
